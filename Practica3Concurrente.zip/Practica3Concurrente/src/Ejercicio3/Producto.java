package Ejercicio3;


public class Producto {
	private int valor;
	
	public Producto(int valor) {
		super();
		this.valor = valor;
	}

	public int getValor() {
		return valor;
	}

	
}
