package Ejercicio2;

//Autores: Jorge Villarrubia, Beatriz Herguedas y Pablo Hern�ndez

public class Main {

	public static void main(String[] args) throws InterruptedException {
		(new BoundedBufferHilos()).ejecutaHilos();
	}

}
