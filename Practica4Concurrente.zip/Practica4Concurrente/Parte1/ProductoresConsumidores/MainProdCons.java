package ProductoresConsumidores;

//Autores: Jorge Villarrubia, Beatriz Herguedas y Pablo Hern�ndez

public class MainProdCons {

	public static void main(String[] args) throws InterruptedException {
		(new HilosProdCons()).ejecutaHilos();
	}

}
