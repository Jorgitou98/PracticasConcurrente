package IncrementosDecrementos;

//Autores: Jorge Villarrubia, Beatriz Herguedas y Pablo Hern�ndez

public class MainIncDec {
	public static void main(String[] args) throws InterruptedException {
		(new HilosIncDec()).ejecutaHilos();
	}
}
