package MultiBufferProdConsLockCond;

public class Producto {
	private int valor;

	
	public Producto() {
		// TODO Auto-generated constructor stub
	}
	
	public Producto(int valor) {
		super();
		this.valor = valor;
	}



	public int getValor() {
		return valor;
	}

	
}
